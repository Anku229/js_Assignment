    let quotes = [
  "'I'm selfish, impatient and a little insecure. I make mistakes, I am out of control and at times hard to handle. But if you can't handle me at my worst, then you sure as hell don't deserve me at my best.'",
  "'Two things are infinite: the universe and human stupidity; and I'm not sure about the universe'",
  "'A room without books is like a body without a soul.'",
  "'You only live once, but if you do it right, once is enough.'",
  "'Be the change that you wish to see in the world.'",
  "'In three words I can sum up everything I've learned about life: it goes on'",
  "'Always forgive your enemies; nothing annoys them so much.'",
  "'No one can make you feel inferior without your consent.'",
  "'Every error is a chance to learn'",
  "'To live is the rarest thing in the world. Most people exist, that is all.'",
  "'Live as if you were to die tomorrow. Learn as if you were to live forever.'",
  "'I am so clever that sometimes I don't understand a single word of what I am saying.'",
  "'Without music, life would be a mistake'",
  "'We accept the love we think we deserve.'",
  "'There is more than one way to write a function'",
  "'You're an array of sunshine'",
  "'Whisper sweet functions in my ear'",
  "'Don't tell anyone, but I really hate IE6'",
  "'!false === it's funny because it's true'",
  "'It was love at first byte'",
  "'@ossia made me do it!'",
  "'I function better at night'"
  ]

 

function getQuote() {
  var randomNumber = Math.floor(Math.random() * quotes.length);
  document.getElementById('newQuoteSection').innerHTML = quotes[randomNumber];
}

